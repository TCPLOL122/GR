This is a style tool to make ascii gradients
Made Bye DreadFulServers 2012-2024
`how to use`

edit "textfile.txt" and use the tags

Example:
```
<<Start: #ee05f2>> ====================== <<End: #f20521>>
This is <<Start: Bold>>bold<<End: Bold>> text.
This is <<Start: Strike>>strike<<End: Strike>> text.
This is <<Start: Underline>>underline<<End: Underline>> text.
along with some normal text
<<Start: #ee05f2>> =====================  <<End: #f20521>>
```

Tags:
```
<<Start: #color>>     || <<End: #color>>
<<Start: Strike>>     || <<End: Strike>>
<<Start: Bold>>       || <<End: Bold>>
<<Start: Underline>>  || <<End: Underline>>
```

> [!NOTE]
> always close tags <<Start:>> <<End:>>
