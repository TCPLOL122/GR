#!/bin/bash

# Uninstall Old Version of Go
echo "Removing old Go version..."
sudo apt-get remove --purge golang* -y
sudo rm -rf /usr/local/go

# Clean up any residual packages
echo "Cleaning up residual packages..."
sudo apt-get autoremove -y
sudo apt-get clean

# Download Golang 1.23.1
echo "Downloading Go 1.23.1..."
wget https://golang.org/dl/go1.23.1.linux-amd64.tar.gz

# Extract the Archive
echo "Extracting Go 1.23.1..."
sudo tar -C /usr/local -xzf go1.23.1.linux-amd64.tar.gz

# Add Go to PATH in .bashrc
echo "Adding Go to PATH..."
echo 'export PATH=$PATH:/usr/local/go/bin' >> ~/.bashrc
source ~/.bashrc

# Verify Installation
echo "Verifying Go installation..."
go version

echo "Go 1.23.1 installation complete."
